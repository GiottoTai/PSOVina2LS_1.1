#!/bin/bash
txt=''
tmp=''
path='./log/log20141202/'
num_run=30
num_complex=201
for i in `seq 1 30`
do
	timeList[${i}]=`more ${path}VINA${i}.txt | tr '[\000-\011\013-\037\177-\377]' '.' | grep 'elapsed' | awk '{print $3}' | tr 'elapsed' ' '`
	rmsdList[${i}]=`more ${path}VINA${i}.txt | tr '[\000-\011\013-\037\177-\377]' '.' | grep 'RMSD to' | awk '{print $6}'` 
    stepList[${i}]=`more ${path}VINA${i}.txt | tr '[\000-\011\013-\037\177-\377]' '.' | grep -n10 'user' | grep 'Terminated' | awk '{print $2}'`

done
for i in `seq 1 201`
do
	for y in `seq 1 ${num_run}`
	do
		tmp_Time=`echo ${timeList[${y}]} | awk '{print $'$i'}'`
		txt_Time=$txt_Time' '$tmp_Time
        tmp_RMSD=`echo ${rmsdList[${y}]} | awk '{print $'$i'}'`
        txt_RMSD=$txt_RMSD' '$tmp_RMSD
		tmp_Step=`echo ${stepList[${y}]} | awk '{print $'$i'}'`
        txt_Step=$txt_Step' '$tmp_Step

	done
	echo $txt_Step >> ${path}/STEP_SUM.txt
	echo $txt_Time >> ${path}/TIME_SUM.txt
    echo $txt_RMSD >> ${path}/RMSD_SUM.txt
	txt_Time=''
	txt_RMSD=''
	txt_Step=''
done


for i in `seq 1 201`
do
	for y in `seq 1 ${num_run}`
	do
		echo $y
		tmp=`sed -n "$i p" ${path}/vina_score_$y.dat |  awk '{print $2}'`
		echo $tmp
		txt=$txt' '$tmp
	done
	echo $txt >> ${path}/ENERGY_SUM.txt

	tmp=''
	txt=''
done
