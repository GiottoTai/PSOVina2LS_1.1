#!/bin/bash
date=20141211
for i in `seq 1 1`
do
	nohup sh ./run_vina.sh $i $date > ./log/log${date}/VINA$i.txt
	sh ./collect_score.sh $i $date
	mv vina_score.dat /log/log${date}/vina_score_$i.dat

done
