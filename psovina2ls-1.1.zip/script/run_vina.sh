#!/bin/bash
# utako: from Kami but modified options in prepare_ligand4 & prepare_receptor4

TOOL_DIR=/usr/local/MGLTools-1.5.7rc1/MGLToolsPckgs/AutoDockTools/Utilities24
#VINA=/home/kami/pso_vina/build/linux/release/vina
VINA=/home/kami/tmp/build/linux/release/psovina
infile=2012_core_name.lst
count=0

for nameList in `grep -v "\#" $infile | cut -f1 -d\ ` ; do  
	#if [ $count -ge 10 ]; then
	# exit 0
	#fi
count=`expr $count + 1`

   echo "================================================"
   echo "================================================"
   echo "[$count]Processing data $nameList "
   echo "================================================"
   echo "================================================"

   mkdir ./log/log${2}/$nameList  
   cd $nameList

   rm ./rmsd2expt.log ./*.pdbqt */fit.pdb ./*randomize.pdb ./*vinadocked.pdb ./vina.log ./vina_score_only.log ./config.txt ./*_ligand.pdb ./fit.log 

   ${TOOL_DIR}/prepare_ligand4.py -l ./${nameList}_ligand.mol2 -o ./${nameList}_ligand.pdbqt -A 'hydrogens' -U 'nphs_lps_waters'
   ${TOOL_DIR}/prepare_receptor4.py -r ./${nameList}_protein.pdb -o ./${nameList}_protein.pdbqt -A 'hydrogens' -U 'nphs_lps_waters' 
    
  # ${TOOL_DIR}/prepare_ligand4.py -l ./${nameList}_ligand.mol2 -o ./${nameList}_ligand.pdbqt -A 'hydrogens' -U 'nphs_lps_waters'
  # ${TOOL_DIR}/prepare_receptor4.py -r ./${nameList}_protein.pdb -o ./${nameList}_protein.pdbqt -A 'hydrogens' -U 'nphs_lps_waters'

   cut -c-66 ${nameList}_ligand.pdbqt > ${nameList}_ligand.pdb   # pdb can be understood by GROMACS
 
   awk -f ../pdbbox.awk ${nameList}_pocket.pdb  > config.txt
 
   (time $VINA --receptor ${nameList}_protein.pdbqt --ligand ${nameList}_ligand.pdbqt --config config.txt --num_modes 1  --log ../log/log${2}/${nameList}/vina${1}.log --cpu 8 --exhaustiveness 8 --out ../log/log${2}/${nameList}/${nameList}_ligand_${1}.pdbqt --num_birds 8 --w 0.33 --c1 0.99 --c2 0.99) 2>&1

   # compare to expt structure
   cut -c-66 ../log/log${2}/${nameList}/${nameList}_ligand_${1}.pdbqt > ../log/log${2}/${nameList}/${nameList}_ligand_${1}.pdb
   echo -e "0\n0" |g_confrms -f1 ${nameList}_ligand.pdb -f2 ../log/log${2}/${nameList}/${nameList}_ligand_${1}.pdb  -nofit > fit.log
   rmsd=`cat fit.log |grep lsq|awk '{ print $9 }'`
   echo "RMSD to expt structure ${nameList}: $rmsd"
   echo $rmsd > ../log/log${2}/${nameList}/rmsd_to_expt_${1}.txt

   cd ../
   #read ans
done

exit 0
